

function addOption(){
    var container = document.getElementById("form");
    var number = document.getElementById("form").length;

    var input = document.createElement("input");
    input.type = "text";
    input.id = "option"+(number+1);
    container.appendChild(input);
    container.appendChild(document.createElement("br"));

}



function calculate(){
    var numberOfOptions = document.getElementById("form").length;
    random = Math.floor(Math.random()* (numberOfOptions)) +1;
    console.log("a választott opció száma: "+ random);
    selectedOption = document.getElementById("option"+random).value;
  

    document.getElementById("result").innerHTML = selectedOption;

}